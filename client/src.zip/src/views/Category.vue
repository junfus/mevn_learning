<template>
  <v-container>
    <v-card>
      <v-card-title>
        <span class="title headline black--text">分类列表</span>
        <v-spacer></v-spacer>
      </v-card-title>
      <v-data-table
        :headers="headers"
        :items="categories"
        item-key="_id"
        class="elevation-2 pa-3"
        multi-sort
        disable-pagination
        hide-default-footer
      >
        <template slot="body.append">
          <tr>
            <th class="title">Total</th>
            <th class="title">150</th>
            <th class="title">260</th>
            <th class="title">150</th>
          </tr>
        </template>
      </v-data-table>
    </v-card>
  </v-container>
</template>

<script>
import CategoryAPI from "../api/api_category";

export default {
  data() {
    return {
      headers: [
        { text: "名称", value: "name" },
        { text: "单位", value: "unit" },
        { text: "出库/入库", value: "out" },
        { text: "备注", value: "comments" },
      ],
      categories: [],
    };
  },

  async created() {
    this.categories = await CategoryAPI.getAllCategories();
    this.categories.forEach((element) => {
      if (element.out) {
        element.out = "出库";
      } else {
        element.out = "入库";
      }
    });
  },
};
</script>
