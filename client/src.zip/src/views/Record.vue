<template>
  <div>
    <v-simple-table>
      <template v-slot:default>
        <thead>
          <tr>
            <th class="text-left">
              Name
            </th>
            <th class="text-left">
              Unit
            </th>
            <th class="text-left">
              Out
            </th>
            <th class="text-left">
              Comments
            </th>
            <th>
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in categories" :key="item._id">
            <td>{{ item.name }}</td>
            <td>{{ item.unit }}</td>
            <td v-if="item.out">出货</td>
            <td v-else>入货</td>
            <td>{{ item.comments }}</td>
            <td>
              <v-dialog
                v-model="formDialog"
                persistent
                max-width="600px"
                :retain-focus="false"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-btn
                    class="ma-2"
                    color="success"
                    dark
                    v-bind="attrs"
                    v-on="on"
                  >
                    <v-icon dark left>
                      {{ icons.mdiUpdate }}
                    </v-icon>
                    更新
                  </v-btn>
                </template>
                <v-card>
                  <v-card-title>
                    <span class="headline">分类</span>
                  </v-card-title>
                  <v-card-text>
                    <v-container>
                      <v-row>
                        <v-col>
                          <v-text-field
                            v-model="item.name"
                            label="Name"
                            clearable
                          ></v-text-field>
                        </v-col>
                      </v-row>
                    </v-container>
                    <small>*indicates required field</small>
                  </v-card-text>
                  <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" dark @click="formDialog = false">
                      取消
                    </v-btn>
                    <v-btn
                      class="ma-2"
                      color="success"
                      dark
                      @click="formDialog = false"
                    >
                      更新
                    </v-btn>
                  </v-card-actions>
                </v-card>
              </v-dialog>

              <v-dialog v-model="dialog" width="500" :retain-focus="false">
                <template v-slot:activator="{ on }">
                  <v-btn class="ma-2" color="red" dark v-on="on">
                    <v-icon dark left>
                      {{ icons.mdiDelete }}
                    </v-icon>
                    删除
                  </v-btn>
                </template>
                <v-card elevation="4" outlined>
                  <v-card-title>删除</v-card-title>
                  <v-card-text>
                    确定要删除这条数据吗?
                  </v-card-text>
                  <v-divider></v-divider>
                  <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" dark @click="dialog = false">
                      取消
                    </v-btn>
                    <v-btn
                      class="ma-2"
                      color="red"
                      dark
                      @click="remove(item._id)"
                    >
                      确定
                    </v-btn>
                  </v-card-actions>
                </v-card>
              </v-dialog>
            </td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>
  </div>
</template>

<script>
import CategoryAPI from "../api/api_category";
import moment from "moment";
import { mdiUpdate, mdiDelete } from "@mdi/js";

export default {
  name: "Category",

  data() {
    return {
      categories: [],
      icons: {
        mdiUpdate,
        mdiDelete,
      },
      message: "",
      dialog: false,
      formDialog: false,
    };
  },

  async created() {
    this.categories = await CategoryAPI.getAllCategories();
  },

  methods: {
    moment,

    async remove(id) {
      const res = await CategoryAPI.deleteCategory(id);
      this.message = res.message;
      this.dialog = false;
      location.reload();
    },
  },
};
</script>
