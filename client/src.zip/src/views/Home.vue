<template>
  <v-container>
    <v-card>
      <v-card-title>
        <span class="headline black--text">明细分类</span>
        <v-spacer></v-spacer>
      </v-card-title>
      <v-row class="pa-3">
        <v-col cols="3" v-for="item in categories" :key="item._id">
          <v-card elevation="2">
            <v-card-title> {{ item.name }}{{ item.out }}明细 </v-card-title>
          </v-card>
        </v-col>
      </v-row>
    </v-card>
  </v-container>
</template>

<script>
import CategoryAPI from "../api/api_category";

export default {
  data() {
    return {
      categories: [],
    };
  },

  async created() {
    this.categories = await CategoryAPI.getAllCategories();
    this.categories.forEach((element) => {
      if (element.out) {
        element.out = "出库";
      } else {
        element.out = "入库";
      }
    });
  },
};
</script>
